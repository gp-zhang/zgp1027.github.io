//
//  JCMapLayer.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/23.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class JCMapView;
@class JCLayer;
@interface JCMapLayer : NSObject
/**
 *  图层
 */
@property (nonatomic,strong) JCLayer *layer;
/**
 *  初始化mapLayer
 *
 *  @param layer 图层
 *
 *  @return JCMapLayer
 */
- (instancetype)initWithLayer:(JCLayer *)layer;
/**
 *  获取图层名称
 *
 *  @return 名称
 */
- (NSString *)getName;
/**
 *  绘制方法,
 *
 *  @param context 上下文
 *  @param left    左x
 *  @param top     上y
 *  @param right   右x
 *  @param bottom  下y
 */
@end
