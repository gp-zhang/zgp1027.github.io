//
//  JCFields.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/22.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"
@class JCField;
@interface JCFields : JCObject
/**
 *  属性域表长度
 *
 *  @return 属性域表长度
 */
- (int)getSize;
/**
 *  按索引获取属性域
 *
 *  @param index 索引
 *
 *  @return JCField
 */
- (JCField *)getFieldByIndex:(int)index;
/**
 *  根据名称获取属性域
 *
 *  @param name 名称
 *
 *  @return JCField
 */
- (JCField *)getFieldByName:(NSString *)name;
@end
