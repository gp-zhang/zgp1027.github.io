//
//  Building.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/22.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JCMapProject.h"

typedef  enum{
    JCBUILDING_RG_STATUS_INIT = 0,
    JCBUILDING_RG_STATUS_LOADING,
    JCBUILDING_RG_STATUS_LOADED
}JCBUILDING_RG_STATUS;

@class JCFloor;
@class JCRouteResultSet;
@class JCMapLocation;
@class JCNavigateChain;
@interface JCPathResult : NSObject
@property (nonatomic,assign) BOOL hasPath;
@property (nonatomic,assign) double distance;
@property (nonatomic,assign) void *handle;

- (int)getNodeCount;
/**
 *  获取路径节点
 *
 *  @param index 索引
 *
 *  @return 地图位置
 */
- (JCMapLocation *)getNode:(int)index;
/**
 *  获取所在楼层的路径
 *
 *  @param floorIndex 楼层索引
 *
 *  @return 路径曲线
 */
- (UIBezierPath *)getBezierPathWithIndex:(int)floorIndex;

@end



@interface JCBuilding : NSObject
/**
 *  building 指针
 */
@property (nonatomic ,assign)void *handle;

/**
 *  初始化类
 *
 *  @param map JCMapProject类的对象
 *  @param name   建筑物的名字
 *
 *  @return 类
 */
- (instancetype)initWithMap:(JCMapProject *)map name:(NSString *)name;
/**
 *  添加楼层地图；注意：添加顺序为其余接口所用的的楼层索引、从0开始
 *
 *  @param map  地图
 *  @param name 名称
 *  @param num  楼层号
 */
- (void)addFloor:(JCMapProject *)map name:(NSString *)name num:(int)num;
/**
 *  获取定位基础数据，"JCLocation.framework - (void)setUP:(NSDictionary *)dict"
 *
 *  @return 定位数据
 */
- (NSDictionary *)getLocationData;
/**
 *  释放建筑物数据
 */
- (void)recycle;
/**
 *  获取建筑物名称
 *
 *  @return 建筑物名称
 */
- (NSString *)getName;

/**
 *  开始加载路图,初始化导航
 */
- (void)loadRouteGraph;

/**
 *  检查路图是否加载完成
 *
 *  @return JCBUILDING_STATUS_LOADED=“完成”
 */
- (JCBUILDING_RG_STATUS)getStatus;

/**
 *  建筑物楼层数
 *
 *  @return 建筑物楼层数
 */
- (int)getFloorCount;

/**
 *  根据楼层索引获取楼层
 *
 *  @param index 楼层索引
 *
 *  @return 楼层
 */
- (JCFloor *)getFloorByIndex:(int)index;

/**
 *  根据num获取楼层
 *
 *  @param num 楼层编号
 *
 *  @return 楼层
 */
- (JCFloor *)getFloorByNum:(int)num;

/**
 设置障碍物

 @param location 障碍物坐标
 */
- (void)setBlock:(JCMapLocation *)location;

/**
 *  从起点简历路径集
 *
 *  @param floorindex 楼层数
 *  @param x          楼层中的x坐标
 *  @param y          楼层中的y坐标
 *
 *  @return digrapg_sr_t的指针
 */
- (JCRouteResultSet *)routePlan:(int)floorindex x:(double)x y:(double)y;


/**
 *  查询start点到end节点的路径数据集对象
 *  end 超出图索引范围 是已检查的异常
 *  如果不可达会返回NULL
 *
 *  @param rrshandle digraph_sr_t指针
 *  @param destkey   目的地的key
 *
 *  @return digraph_path_t指针
 */
/**
 *  根据已有起点路径集获取到达终点的路径
 *
 *  @param route      路径集
 *  @param floorindex 楼层索引
 *  @param x          x坐标
 *  @param y          y坐标
 *  @param getpath    是否获取路径，NO：用作单纯提取路径距离及判断是否有路径时
 *
 *  @return 路径
 */
- (JCPathResult *)getPath:(JCRouteResultSet *)route floorIndex:(int)floorindex x:(double)x y:(double)y getPath:(BOOL)getpath;

/**
 *  释放路径集对象
 *
 *  @param route 路径集
 */
- (void)routeRecycle:(JCRouteResultSet *)route;

/**
 *  根据路径获取导航链:用作计算语音提示的内容
 *
 *  @param path    路径
 *  @param azimuth 角度
 *
 *  @return 导航链
 */
- (JCNavigateChain *)getNavigateChain:(JCPathResult *)path mapAzimuth:(double)azimuth;


/**
  获取到定位点到地图可通行区域的投影点

 
 @return 
 */
- (JCMapLocation * )getNearLocation:(JCMapLocation *)loc;

@end
