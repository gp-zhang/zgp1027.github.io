//
//  Layer.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/22.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"
@class JCFeature;
@class JCSymbol;
@class JCFields;
//图层
@interface JCLayer : JCObject
/**
*  获取图层名称
*
*  @return 图层名称
*/
- (NSString *)getName;
/**
 *  获取图层属性域表
 *
 *  @return JCFields对象
 */
- (JCFields *)getFields;
/**
 *  获取符号
 *
 *  @return JCSymbol对象
 */
- (JCSymbol *)getSymbol;
/**
 *  根据id获取图层要素
 *
 *  @param fid 要素id
 *
 *  @return JCFeature 对象
 */
- (JCFeature *)getFeatureById:(int)fid;
/**
 *  根据索引获取图层要素
 *
 *  @param index 索引
 *
 *  @return JCFeature 对象
 */
- (JCFeature *)getFeatureByIndex:(int)index;
/**
 *  获取要素数量
 *
 *  @return 要素数量
 */
- (int)getFeatureCount;

/**
 *  检查传入的点是否被图层中任意要素包含
 *
 *  @param x x坐标
 *  @param y y坐标
 *
 *  @return
 */
- (BOOL)containCheckX:(double)x Y:(double)y;
/**
 *  检查传入的矩形范围是否与图层中任意要素相交
 *
 *  @param left   左x
 *  @param top    上y
 *  @param right  右x
 *  @param bottom 下y
 *
 *  @return
 */
- (BOOL)intersectCheckLeft:(double)left top:(double)top right:(double)right bottom:(double)bottom;

/**
 *  空间搜索, 返回在距离传入的矩形范围maxdistance内的要素
 *
 *  @param left   左x
 *  @param top    上y
 *  @param right  右x
 *  @param bottom 下y
 *  @param maxdist  距离
 *  @param maxcount maxcount指定搜索的结束条件, 当达到最大数目后马上返回
 *
 *  @return 要素列表
 */
- (NSArray *)searchLeft:(double)left top:(double)top right:(double)right bottom:(double)bottom maxDist:(double)maxdist maxCount:(int)maxcount;

/**
 *  通过图层的标注格式 ,和特定的要素, 生成相关的标注字符串
 *
 *  @param feature 要素
 *
 *  @return 标注字符串
 */
- (NSString *)getAnnotation:(JCFeature *)feature;
@end
