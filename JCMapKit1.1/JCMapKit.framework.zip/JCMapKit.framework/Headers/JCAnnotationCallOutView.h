//
//  JCAnnotationCallOutView.h
//  JCMapKit
//
//  Created by JCNetwork on 16/1/25.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JCMapView,JCAnnotation;
/**
 *  气泡视图
 */
@interface JCAnnotationCallOutView : UIView
/**
 *  x=0时为左右居中、y请自行调整
 */
@property (nonatomic, readonly) CGPoint point;

@property (nonatomic, assign) CGPoint offset;

@property (nonatomic, assign) CGPoint annotationoffset;

- (void)setPosition:(CGPoint )position;

/**
 *  初始化方法
 *
 *  @param mapView 关联地图
 *
 *  @return 气泡视图实例
 */
- (id)initOnMapView:(JCMapView *)mapView;
/**
 *  更新位置
 */
- (void)updatePosition;

/**
 *  是否显示默认气泡,默认为NO
 */
@property(nonatomic, assign) BOOL showDefaultStyle;
/**
 *  当showDefaultStyle为YES,才会有titleLabel
 */
@property (nonatomic, readonly) UILabel *titleLabel;

@end
