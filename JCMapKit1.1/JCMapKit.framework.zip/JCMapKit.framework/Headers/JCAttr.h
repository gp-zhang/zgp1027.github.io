//
//  JCAttr.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/22.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"
@class JCElement;
@interface JCAttr : JCObject
/**
 *  获取属性表中的元素数目
 *
 *  @return 属性表中的元素数目
 */
- (int)getSize;
/**
 *  按名字获取某元素(不是通过字符串比较, 效率高)
 *
 *  @param name 元素名字
 *
 *  @return JCElement
 */
- (JCElement *)getElementByName:(NSString *)name;
/**
 *  按索引获取某元素
 *
 *  @param index 索引
 *
 *  @return JCElement
 */
- (JCElement *)getElementByIndex:(int)index;
@end
