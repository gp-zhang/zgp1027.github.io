//
//  JCElement.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/22.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"
typedef  enum{
    JCELEMENT_TYPE_NULL = 1024,
    JCELEMENT_TYPE_INT,
    JCELEMENT_TYPE_DOUBLE,
    JCELEMENT_TYPE_TEXT,
    JCELEMENT_TYPE_BLOB
}JCELEMENT_TYPE;

@interface JCElement : JCObject

/**
 *  访问元素的键名
 *
 *  @return 元素的键名
 */
- (NSString *)getName;
/**
 *  访问元素的数据类型
 *
 *  @return 元素的数据类型
 */
- (JCELEMENT_TYPE)getType;
/**
 *  按类型访问元素数据
 *
 *  @return 元素数据
 */

/**
 *  获取当前元素的整型数据
 *
 *  @return int数据
 */
- (int)getInt;
/**
 *  获取当前元素的浮点数据
 *
 *  @return double数据
 */
- (double)getDouble;
/**
 *  获取元素大小
 *
 *  @return 元素大小
 */
- (int)getSize;
/**
 *  获取文本类型数据
 *
 *  @return 文本
 */
- (NSString *)getText;
/**
 *  获取二进制数据
 *
 *  @return NSData对象
 */
- (NSData *)getBlob;
@end
