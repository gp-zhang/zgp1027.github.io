//
//  JCMapLocation.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/23.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCMapLocation : NSObject

/**
 楼层索引,以jmk添加顺序为准
 */
@property (nonatomic,assign) int floorIndex;

/**
 地图X坐标
 */
@property (nonatomic,assign) float mapX;

/**
 地图Y坐标
 */
@property (nonatomic,assign) float mapY;
/**
 *  使用楼层索引及坐标值初始化
 *
 *  @param floorindex 楼层索引
 *  @param x          x坐标
 *  @param y          y坐标
 *
 *  @return JCMapLocation
 */
- (instancetype)initWithFloor:(int)floorindex X:(float)x Y:(float)y;

@end
