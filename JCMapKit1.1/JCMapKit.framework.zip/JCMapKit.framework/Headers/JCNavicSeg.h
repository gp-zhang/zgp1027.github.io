//
//  JCNavicSeg.h
//  JCMapKit
//
//  Created by JCNetwork on 16/3/5.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"
/**
 *  导航链中的段
 */
@interface JCNavicSeg : JCObject
/**
 *  获取楼层索引
 *
 *  @return 楼层索引
 */
- (int)getFloorIndex;
/**
 *  获取当前段的索引
 *
 *  @return 索引值
 */
- (int)getSegIndex;
/**
 *  缩放
 *
 *  @return 缩放
 */
- (double)getScale;
/**
 *  获取当前段的起点x
 *
 *  @return 起点x
 */
- (double)getStartX;
/**
 *  获取当前段的起点y
 *
 *  @return 起点y
 */
- (double)getStartY;
/**
 *  获取当前段的终点x
 *
 *  @return 终点x
 */
- (double)getEndX;
/**
 *  获取当前段的终点y
 *
 *  @return 终点y
 */
- (double)getEndY;
/**
 *  获取方位角
 *
 *  @return 方位角
 */
- (double)getAzimuth;

@end
