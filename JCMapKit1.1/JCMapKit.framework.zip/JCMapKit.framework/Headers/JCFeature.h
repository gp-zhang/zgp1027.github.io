//
//  JCFeature.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/22.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"
@class JCEnvelop;
@class JCAttr;
@class JCGeometry;
/**
 *  图上具体的POI个体
 */
@interface JCFeature : JCObject
/**
 *  访问要素的主键
 *
 *  @return 主键值
 */
- (int)getId;

/**
 获取name字段

 @return name
 */
- (NSString *)getName;

/**
 *  访问要素的唯一标识
 *
 *  @return 标识
 */
- (NSString *)getGUID;
/**
 *  获取要素的几何类型
 *
 *  @return 类型
 */
- (NSString *)getType;
/**
 *  要素所属的图层名称
 *
 *  @return 图层名称
 */
- (NSString *)getLayerName;
/**
 *  访问要素的外切矩形
 *
 *  @return JCEnvelop
 */
- (JCEnvelop *)getExtent;

- (CGPoint)getCenter;
/**
 *  获取属性表
 *
 *  @return JCAttr
 */
- (JCAttr *)getAttr;
/**
 *  获取几何对象
 *
 *  @return JCGeometry
 */
- (JCGeometry *)getGeometry;
@end
