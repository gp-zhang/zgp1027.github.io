//
//  JCNavigateChain.h
//  JCMapKit
//
//  Created by JCNetwork on 16/3/5.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"
@class JCNavicSeg;
@class JCNavicStatus;
@class JCMapLocation;
@class JCPathResult;
@interface JCNavigateChain : JCObject
/**
 *  获取段的数量
 *
 *  @return 数量
 */
- (int)getSegCount;
/**
 *  根据索引获取段
 *
 *  @param index 索引值
 *
 *  @return JCNavicSeg
 */
- (JCNavicSeg *)getSeg:(int)index;
/**
 *  获取方位角
 *
 *  @return 方位角
 */
- (double)getAzimuth;


/**
 获取第一段路线的角度，用作地图旋转

 @return 弧度
 */
- (double)getAzimuthFirst;
/**
 *  根据位置和方位角获取状态信息
 *
 *  @param loc     位置
 *  @param azimuth 方位角
 *
 *  @return JCNavicStatus
 */
- (JCNavicStatus *)getStatus:(JCMapLocation *)loc azimuth:(double)azimuth;


/**
 获取当前楼层的路径

 @param floorIndex 楼层索引
 @return UIBezierPath
 */
- (UIBezierPath *)getBezierPathWithIndex:(int)floorIndex;
@end
