//
//  JCColor.h
//  JCMapKit
//
//  Created by JCNetwork on 16/3/5.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCColor : NSObject
/**
 *  颜色转换
 *
 *  @param color 整型色值
 *
 *  @return UIColor
 */
+ (UIColor *)getColorWithInt:(int)color;

@end
