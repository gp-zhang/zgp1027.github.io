//
//  JCRouteResultSet.h
//  JCMapKit
//
//  Created by JCNetwork on 16/3/2.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"
/**
 *  路径集
 */
@interface JCRouteResultSet : JCObject

@end
