//
//  JCObject.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/25.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface JCObject : NSObject
@property (nonatomic ,assign) void *handle;
- (instancetype)initWithHandle:(void *)handle;
- (void)check;
@end
