//
//  JCFloor.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/22.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"
@class JCMapProject;
@interface JCFloor : JCObject
/**
 *  获取map
 *
 *  @return JCMapProject对象
 */
- (JCMapProject *)getMap;
/**
 *  获取楼层索引
 *
 *  @return 楼层索引
 */
- (int)getIndex;
/**
 *  获取楼层编号
 *
 *  @return 楼层编号
 */
- (int)getNumber;
/**
 *  楼层描述
 *
 *  @return 楼层描述
 */
- (NSString *)getDes;
@end
