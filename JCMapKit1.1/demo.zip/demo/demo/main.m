//
//  main.m
//  demo
//
//  Created by zgp on 16/10/27.
//  Copyright © 2016年 重庆甲虫网络科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
