//
//  JCUserAnnotationView.m
//  Demo
//
//  Created by zgp on 16/5/27.
//  Copyright © 2016年 zgp. All rights reserved.
//

#import "JCUserAnnotationView.h"

@interface JCUserAnnotationView()
{
    CAShapeLayer *_scaleLayer;
    CAShapeLayer *_backgroundLayer;
}
@end
@implementation JCUserAnnotationView



- (id)initWithAnnotation:(JCAnnotation *)annotation
{
    self = [super initWithAnnotation:annotation];
    if (self) {
        self.annotation = annotation;
        self.animating = NO;
      
    }
    return self;
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    [self.layer insertSublayer:[self scaleLayer] atIndex:0];
    [self.layer insertSublayer:[self backgroundLayer] atIndex:0];
    [self setAnimating:YES];
}

- (void)setAnimating:(BOOL)animating
{
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"lineWidth"];
    
    // 动画选项设定
    animation.duration = 1.0; // 动画持续时间
    animation.repeatCount = MAXFLOAT; // 重复次数
    animation.autoreverses = YES; // 动画结束时执行逆动画
    
    // 缩放倍数
    animation.fromValue = [NSNumber numberWithFloat:3.0]; // 开始时的倍率
    animation.toValue = [NSNumber numberWithFloat:7.0]; // 结束时的倍率
    
    // 添加动画
    [_scaleLayer addAnimation:animation forKey:@"scale-layer"];
}



- (CAShapeLayer *)backgroundLayer
{
    if (_backgroundLayer.superlayer) {
        [_backgroundLayer removeFromSuperlayer];
    }
    _backgroundLayer = nil;
    if (!_backgroundLayer) {
        CGRect trackRect = self.bounds;
        _backgroundLayer = [self circleLayerWithRect:trackRect
                                         strokeColor:[UIColor clearColor]
                                         shadowColor:[UIColor clearColor]
                                           fillColor:[[UIColor colorWithRed:0.267f green:0.706f blue:0.992f alpha:1.00f] colorWithAlphaComponent:0.2]
                                           lineWidth:0.0];
        _backgroundLayer.lineWidth = 0.0f;
        _backgroundLayer.anchorPoint = CGPointMake(0.5, 0.5);
    }
    return _backgroundLayer;
}

- (CAShapeLayer *)scaleLayer
{
    if (_scaleLayer.superlayer) {
        [_scaleLayer removeFromSuperlayer];
    }
    _scaleLayer = nil;
    if (!_scaleLayer) {
        
        CGRect trackRect = CGRectInset(self.bounds, 25.0f/80.0f*(self.bounds.size.width), 25.0f/80.0f*(self.bounds.size.width));
        _scaleLayer = [self circleLayerWithRect:trackRect
                                    strokeColor:[UIColor whiteColor]
                                    shadowColor:[UIColor clearColor]
                                      fillColor:[UIColor colorWithRed:0.267f green:0.706f blue:0.992f alpha:1.00f]
                                      lineWidth:0.0f];
        _scaleLayer.lineWidth = 03.0f;
        _scaleLayer.anchorPoint = CGPointMake(0.5, 0.5);
    }
    return _scaleLayer;
}


- (UIBezierPath *)circlePathInRect:(CGRect)circleRect
{
    CGFloat radians = (90 * M_PI) / 180;
    CGFloat radius = CGRectGetWidth(circleRect) / 2.0f;
    CGPoint center = (CGPoint) { CGRectGetMidX(circleRect), CGRectGetMidY(circleRect) };
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:(CGPoint) { CGRectGetMidX(circleRect), CGRectGetMinY(circleRect) }];
    [path addArcWithCenter:center radius:radius startAngle:-(radians) endAngle:0 clockwise:YES];
    [path addArcWithCenter:center radius:radius startAngle:0 endAngle:radians clockwise:YES];
    [path addArcWithCenter:center radius:radius startAngle:radians endAngle:(radians * 2) clockwise:YES];
    [path addArcWithCenter:center radius:radius startAngle:(radians * 2) endAngle:-(radians) clockwise:YES];
    [path closePath];
    return path;
}

- (CAShapeLayer *)circleLayerWithRect:(CGRect)circleRect
                          strokeColor:(UIColor *)strokeColor
                          shadowColor:(UIColor *)shadowColor
                            fillColor:(UIColor *)fillColor
                            lineWidth:(float )lineWidth
{
    UIBezierPath *path = [self circlePathInRect:circleRect];
    CAShapeLayer *circleLayer = [CAShapeLayer new];
    circleLayer.masksToBounds = NO;
    circleLayer.path = path.CGPath;
    circleLayer.fillColor = fillColor.CGColor;
    circleLayer.strokeColor = strokeColor.CGColor;
    circleLayer.lineWidth = lineWidth;
    
    if (shadowColor) {
        circleLayer.shadowPath = path.CGPath;
        circleLayer.shadowColor = shadowColor.CGColor;
        circleLayer.shadowOpacity = 0.85f;
        circleLayer.shadowRadius = 5.0;
        circleLayer.shadowOffset = CGSizeZero;
    }
    
    circleLayer.shouldRasterize = YES;
    circleLayer.rasterizationScale = [[UIScreen mainScreen] scale];
    circleLayer.anchorPoint = (CGPoint) { 0.5f, 0.5f };
    return circleLayer;
}


@end
