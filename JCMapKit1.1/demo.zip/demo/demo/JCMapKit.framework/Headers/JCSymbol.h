//
//  Symbol.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/22.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"
typedef  enum {
    JCSYMBOL_TYPE_UNKNOWN = 2048,
    JCSYMBOL_TYPE_POINT,
    JCSYMBOL_TYPE_POLYLINE,
    JCSYMBOL_TYPE_POLYGON,
}JCSYMBOL_TYPE;

/**
 * 符号对象, 用于描述属于某逻辑图层的要素
 * 在的默认渲染方式
 */

typedef  enum {
    JCSYMBOL_STYLE_NULL = 0,                      /*不渲染*/
    
    JCSYMBOL_STYLE_FILL_SOLID,                    /*实填充*/
    JCSYMBOL_STYLE_FILL_HORIZONTAL,               /*水平样条填充*/
    JCSYMBOL_STYLE_FILL_VERTICAL,                 /*竖直样条填充*/
    JCSYMBOL_STYLE_FILL_FORWARD_DIAGONAL,         /*前向斜样条填充*/
    JCSYMBOL_STYLE_FILL_BACKWARD_DIAGONAL,        /*后向斜样条填充*/
    JCSYMBOL_STYLE_FILL_CROSS,                    /*十字交叉样条填充*/
    JCSYMBOL_STYLE_FILL_DIAGONAL_CROSS,           /*斜十字交叉样条填充*/
    
    JCSYMBOL_STYLE_MARKER_CIRCLE,                 /*圆点标记*/
    JCSYMBOL_STYLE_MARKER_CROSS,                  /*十字标记*/
    JCSYMBOL_STYLE_MARKER_DIAMOND,                /*钻石(菱形)标记*/
    JCSYMBOL_STYLE_MARKER_SQUARE,                 /*方块标记*/
    JCSYMBOL_STYLE_MARKER_TRIANGLE,               /*三角形标记*/
    JCSYMBOL_STYLE_MARKER_X,                      /*X标记*/
    
    JCSYMBOL_STYLE_LINE_DASH,                     /*划线*/
    JCSYMBOL_STYLE_LINE_DASHDOT,                  /*点划线*/
    JCSYMBOL_STYLE_LINE_DASHDOTDOT,               /*点点划线*/
    JCSYMBOL_STYLE_LINE_DOT,                      /*点线*/
    JCSYMBOL_STYLE_LINE_SOLID                     /*实线*/
}JCSYMBOL_STYLE;

@interface JCSymbol : JCObject

/**
 *  获取几何类型
 *
 *  @return JCSYMBOL_TYPE
 */
- (JCSYMBOL_TYPE)getType;
/**
 *  获取符号风格
 *
 *  @return JCSYMBOL_STYLE
 */
- (JCSYMBOL_STYLE)getStyle;
/**
 *  获取颜色
 *
 *  @return UIColor
 */
- (UIColor *)getColor;
/**
 *  获取描边颜色
 *
 *  @return UIColor
 */
- (UIColor *)getStrokeColor;
/**
 *  获取大小
 *
 *  @return 
 */
- (float)getSize;
@end
