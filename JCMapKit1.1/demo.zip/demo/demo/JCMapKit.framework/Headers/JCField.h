//
//  JCField.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/22.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"
typedef  enum{
    JCFIELD_TYPE_NULL = 1024,
    JCFIELD_TYPE_INT,
    JCFIELD_TYPE_DOUBLE,
    JCFIELD_TYPE_TEXT,
    JCFIELD_TYPE_BLOB
}JCFIELD_TYPE;
@interface JCField : JCObject
/**
 *  访问属性域的名字
 *
 *  @return 属性域的名字
 */
- (NSString *)getName;
/**
 *  访问属性域的类型 和element_t采用同一类型宏
 *
 *  @return 属性域的类型 和element_t采用同一类型宏
 */
- (JCFIELD_TYPE)getType;
@end
