//
//  JCMapKit.h
//  JCMapKit
//
//  Created by zgp on 16/10/27.
//  Copyright © 2016年 重庆甲虫网络科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JCMapView.h"
#import "JCAnnotation.h"
#import "JCAnnotationView.h"
#import "JCAnnotationCallOutView.h"
#import "JCMapLayer.h"

#import "JCAttr.h"
#import "JCElement.h"
#import "JCEnvelop.h"
#import "JCFeature.h"
#import "JCField.h"
#import "JCFields.h"
#import "JCFloor.h"
#import "JCGeometry.h"
#import "JCLayer.h"
#import "JCObject.h"
#import "JCSymbol.h"
#import "JCRouteResultSet.h"
#import "JCMapLocation.h"
#import "JCMapLayer.h"
#import "JCColor.h"
#import "JCNavigateChain.h"
#import "JCNavicSeg.h"
#import "JCNavicStatus.h"
#import "JCBuilding.h"
#import "JCMapProject.h"
#import <CoreLocation/CoreLocation.h>
@protocol JCMapKitDelegate<NSObject>

/**
 指南针数据回调

 @param newHeading  
 */
- (void)updateHeading:(CLHeading *)newHeading;


/**
 位置更新回调

 @param location JCMapLocation实例
 */
- (void)updateUserLocation:(JCMapLocation *)location;
@end
@interface JCMapKit : NSObject

/**
 地图管理单例

 @return JCMapKit
 */
+ (instancetype)getInstance;

/**
 代理
 */
@property (nonatomic,weak) id<JCMapKitDelegate> delegate;

/**
 加载建筑物

 @param plist  filepath
 */
- (void)loadBuilding:(NSString *)plist;

/**
 获取Building

 @return JCBuilding实例
 */
- (JCBuilding *)getBuilding;

/**
 开启定位
 */
- (void)startUpdateUserLocation;

/**
 结束定位
 */
- (void)stopUpdateUserLocation;


/**
 获取导航数据；mapView画线及获取文字提示时使用

 @param startLoc 起点坐标
 @param endLoc 终点坐标
 @return JCNavigateChain实例
 */
- (JCNavigateChain *)getNavigateChain:(JCMapLocation *)startLoc end:(JCMapLocation *)endLoc;


/**
 重置导航
 */
- (void)resetNavigateChain;

/**
 获取到定位点到地图可通行路线的投影点

 @param loc JCMapLocation实例
 @return 投影后的JCMapLocation实例
 */
- (JCMapLocation *)getProjectionLocation:(JCMapLocation *)loc;
@end
