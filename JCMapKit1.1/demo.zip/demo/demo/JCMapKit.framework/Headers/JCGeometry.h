//
//  Geometry.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/22.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"

typedef  enum{
    JCGEOMETRY_TYPE_UNKNOWN = 2048,
    JCGEOMETRY_TYPE_POINT,
    JCGEOMETRY_TYPE_POLYLINE,
    JCGEOMETRY_TYPE_POLYGON
}JCGEOMETRY_TYPE;
/**
 *  几何对象
 */
@interface JCGeometry : JCObject
/**
 *  获取对象类别
 *
 *  @return 类别
 */
- (JCGEOMETRY_TYPE)getType;
/**
 *  获取对象维度
 *
 *  @return 维度
 */
- (int)getDim;
/**
 *  获取对象节点数目
 *
 *  @return 节点数目
 */
- (int)getCount;
/**
 *
 * 按节点偏移, 和维度获取几何数据
 * 以 二维 point类型举例 只有一个节点 offset为0
 *  dim==0 获取x坐标数据 dim==1获取y坐标数据
 * 以 三维 polygon类型举例 有n个节点 第i个节点offset==i
 *  dim==0 获取x坐标数据 dim==1获取y坐标数据 dim==2获取z坐标
 * 以此类推
 *  @param offset 偏移值,点的索引
 *  @param dim    维度;0:x、1:y
 *
 *  @return 当前维度坐标值
 */
- (double)getData:(int)offset dim:(int)dim;
@end
