//
//  JCAnnotationView.h
//  JCMapKit
//
//  Created by JCNetwork on 15/12/18.
//  Copyright © 2015年 JCNetwork. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JCAnnotation;
/**
 *  AnnotationView
 */
@interface JCAnnotationView : UIView
/**
 *  Annotation
 */
@property (nonatomic,assign)JCAnnotation *annotation;
/**
 *  初始化方法
 *
 *  @param annotation Annotation
 *
 *  @return AnnotationView实例
 */
- (id)initWithAnnotation:(JCAnnotation *)annotation;
@end
