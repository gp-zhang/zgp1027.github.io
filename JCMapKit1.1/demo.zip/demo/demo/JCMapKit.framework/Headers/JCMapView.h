//
//  JCMapView.h
//  JCMapKit
//
//  Created by JCNetwork on 15/Users/JCNetwork/Library/Developer/Xcode/DerivedData/JCShowMap-cydlugqtkacfdqgplnmhmxykvsoh/Build/Products/Debug-iphoneos/JCShowMap.framework/12/17.
//  Copyright © 2015年 JCNetwork. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
@class JCAnnotationView;
@class JCNavigateChain;
 static  NSString* LAYER_STALL         = @"stall";
 static  NSString* LAYER_AP            = @"ap";
 static  NSString* LAYER_WC            = @"wc";
 static  NSString* LAYER_SERV_DESK     = @"serv_desk";
 static  NSString* LAYER_EXIT          = @"port";
 static  NSString* LAYER_STAIRWAY      = @"stairway";
 static  NSString* LAYER_ESCALATOR     = @"escalator";
 static  NSString* LAYER_ELEVATOR      = @"elevator";
 static  NSString* LAYER_MEETING       = @"meeting_room";
 static  NSString* LAYER_NEGOTIATE     = @"negotiate_room";


@class JCAnnotation;
@class JCAnnotationCallOutView;
@class JCMapLayer;
@class JCBuilding;
@class JCFloor;
@class JCFeature;
@protocol JCMapViewDelegate;
/**
 *  地图视图
 */
@interface JCMapView : UIView
/**
 *  加载建筑物
 *
 *  @param building JCBuilding实例
 */
- (void)loadBuilding:(JCBuilding *)building;

- (JCBuilding *)getBuilding;
- (void)setCurrentFloor:(int)floorIndex;
- (JCFloor *)getFloor:(int)floorIndex;
- (void)addLayer:(NSString *)layername image:(UIImage *)image;
- (JCMapLayer *)getLayer:(NSString *)layername;
- (NSArray *)getLayerFeatures:(NSString *)layername;


/**
 设置LAYER_STALL图层要素颜色

 @param feature JCFeature实例
 @param color 
 */
- (void)setStallColor:(JCFeature *)feature color:(UIColor *)color;

/**
 设置LAYER_STALL图层要素文字

 @param feature JCFeature实例
 @param text 显示文本
 */
- (void)setStallText:(JCFeature *)feature text:(UIColor *)text;
/**
 *  添加图层
 *
 *  @param layer 图层
 */
- (void)addLayer:(JCMapLayer *)layer;
/**
 *  移除图层
 *
 *  @param layer 图层
 */
- (void)removeLayer:(NSString *)layername;
/**
 *  清空图层
 */
- (void)cleanLayer;
/**
 *  添加Annotation
 *
 *  @param annotation Annotation
 *  @param animate    YES会出现掉落动画
 */
- (void)addAnnotation:(JCAnnotation *)annotation animated:(BOOL)animate;
/**
 *  批量添加Annotation
 *
 *  @param annotations Annotation数组
 *  @param animate YES会出现掉落动画
 */
- (void)addAnnotations:(NSArray *)annotations animated:(BOOL)animate;
/**
 *  移除Annotation
 *
 *  @param annotation Annotation
 */
- (void)removeAnnotation:(JCAnnotation *)annotation;
/**
 *  批量移除Annotation
 *
 *  @param annotations Annotation数组
 */
- (void)removeAnnotations:(NSArray *)annotations;


/**
 *  基于当前缩放比例的点的转换
 *
 *  @param point 原始点
 *
 *  @return 缩放计算后的点
 */
- (CGPoint)zoomRelativePoint:(CGPoint)point;
/**
 *  Annotation被选中后，会居中显示
 *
 *  @param annotation Annotation
 *  @param animate    动画开关
 */
- (void)selectAnnotation:(JCAnnotation *)annotation animated:(BOOL)animate;
/**
 *  居中显示点
 *
 *  @param point   需要居中的点
 *  @param animate 动画开关
 */
- (void)centerOnPoint:(CGPoint)point animated:(BOOL)animate;
/**
 *  搜索当前点的所有要素
 *
 *  @param point  搜索点
 *  @param radius 半径
 *
 *  @return 要素字典:key为图层名称，value为要素数组
 */
- (NSDictionary *)searchPoint:(CGPoint )point radius:(float)radius;
/**
 *  显示气泡
 *
 *  @param position 气泡显示位置
 *  @param offset   偏移
 *  @param animated 是否显示动画
 */
- (void)showCalloutForPosition:(CGPoint)position offset:(CGPoint )offset animated:(BOOL)animated;
/**
 *  隐藏气泡
 */
- (void)hideCallOut;
/**
 *  地图上添加的所有Annotation
 */
@property (readonly,nonatomic, strong) NSMutableArray *annotations;
/**
 *  气泡视图,只支持单一气泡
 */
@property (nonatomic, strong) JCAnnotationCallOutView *calloutView;
/**
 *  地图代理
 */
@property ( nonatomic, assign) id<JCMapViewDelegate> delegate;
/**
 *  地图初始大小
 */
@property (readonly, nonatomic, assign) CGSize originalSize;

/**
 缩放比例
 */
@property (readonly,nonatomic,assign) CGFloat zoomScale;


/**
 导航模式下地图自动旋转;旋转模式下不能进行地图交互;默认为NO
 */
@property (nonatomic,assign)BOOL rotateWhenNavigate;

/**
  设置导航链、显示路径;   nil为清除路径显示(结束导航)
 */
@property (nonatomic,strong)JCNavigateChain *navigateChain;

/**
 设置导航路径颜色
 */
@property (nonatomic,strong)UIColor *navigateChainColor;

/**
 路线拐角箭头颜色;  nil则不显示拐角箭头
 */
@property (nonatomic,strong)UIColor *navigateRoundCornerColor;

/**
 路线宽度，默认20pt
 */
@property (nonatomic, assign) float navigateChainWidth;

@end

@protocol JCMapViewDelegate <NSObject>

@optional

/**
 点击地图要素

 @param mapView 关联地图

 @param feature JCFeature
 */
- (void)mapView:(JCMapView *)mapView tappedFeature:(JCFeature *)feature;

/**
 地图点击

 @param mapView 关联地图
 @param location 地图坐标
 */
- (void)mapView:(JCMapView *)mapView tappedOnLocation:(CGPoint )location;

/**
 *  Annotation点击事件
 *
 *  @param mapView 关联地图
 *  @param annotation 被点击的Annotation
 */
- (void)mapView:(JCMapView *)mapView tappedOnAnnotation:(JCAnnotation *)annotation;


/**
 *  缩放比例变化后
 *
 *  @param mapView 关联地图
 *  @param level   新的缩放比例
 */
- (void)mapView:(JCMapView *)mapView hasChangedZoomLevel:(CGFloat)level;

/**
 *  用于AnnotationView的自定义
 *
 *  @param mapView    关联的地图
 *  @param annotation Annotation
 *
 *  @return AnnotationView
 */
- (JCAnnotationView *)mapView:(JCMapView *)mapView viewForAnnotation:(JCAnnotation *)annotation;
@end
