//
//  JCMapProject.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/22.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#define JCLAYERWC @"wc"
#define JCLAYERSERVDESK @"serv_desk"
#define JCLAYERPORT @"port"
#define JCLAYERSTAIRWAY @"stairway"
#define JCLAYERESCALATOR @"escalator"
#define JCLAYERELEVATOR @"elevator"
#define JCLAYERMEETINGROOM @"meeting_room"
#define JCLAYERNEGOTIATEROOM @"negotiate_room"
#define JCLAYERVIPROOM @"vip_room"
#define JCLAYERSTALL @"stall"

#import <Foundation/Foundation.h>
@class JCLayer,JCEnvelop;
@interface JCMapProject : NSObject
@property (nonatomic ,assign)void *handle;
- (instancetype)initWithHandle:(void *)handle;

- (instancetype)initWithMap:(NSString *)path;
/**
 * 释放地图数据, 释放其内存池
 */
- (void)recycle;
/**
 *  获取地图名称
 *
 *  @return 地图名称
 */
- (NSString *)getName;
/**
 *  获取地图版本
 *
 *  @return 地图版本
 */
- (int)getVersion;
/**
 *  获取地图掩码
 *
 *  @return 地图掩码
 */
- (unsigned int)getMask;
/**
 *  获取地图信标起始偏移
 *
 *  @return 地图信标起始偏移
 */
- (unsigned int)getObjId;
/**
 *  获取纬度
 *
 *  @return 纬度
 */
- (double)getLng;
/**
 *  获取经度
 *
 *  @return 经度
 */
- (double)getLat;
/**
 *  获取海拔
 *
 *  @return 海拔
 */
- (double)getAlt;
/**
 *  获取方位角
 *
 *  @return 方位角
 */
- (double)getAzimuth;
/**
 *  获取横向x轴缩放比例
 *
 *  @return x缩放
 */
- (double)getScaleX;
/**
 *  获取纵向y轴缩放比例
 *
 *  @return y缩放
 */
- (double)getScaleY;
/**
 *  获取缩放比例、此值为x-y平均值
 *
 *  @return 缩放比例
 */
- (double)getScale;

- (double)getGrid;
/**
 *  获取图层数量
 *
 *  @return 图层数量
 */
- (int)getLayerCount;
/**
 *  通过索引获取图层
 *
 *  @param index 图层索引
 *
 *  @return JCLayer
 */
- (JCLayer *)getLayerByIndex:(int)index;
/**
 *  通过名称获取图层
 *
 *  @param name 图层名称
 *
 *  @return JCLayer
 */
- (JCLayer *)getLayerByName:(NSString *)name;
/**
 *  获取地图外切矩形
 *
 *  @return 外切矩形
 */
- (JCEnvelop *)getExtent;
@end
