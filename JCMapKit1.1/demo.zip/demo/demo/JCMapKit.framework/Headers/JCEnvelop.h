//
//  JCEnvelop.h
//  JCMapKit
//
//  Created by JCNetwork on 16/2/22.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#import "JCObject.h"
/**
 *  相当于一个外切矩形
 */
@interface JCEnvelop : JCObject
/**
 *  获取中心点X坐标
 *
 *  @return x坐标
 */
- (double)getCenterX;
/**
 *  获取中心点Y坐标
 *
 *  @return y坐标
 */
- (double)getCenterY;
/**
 *  获取左边x坐标
 *
 *  @return 左边x坐标
 */
- (double)getLeft;
/**
 *  获取上边y坐标
 *
 *  @return 上边y坐标
 */
- (double)getTop;
/**
 *  获取右边x坐标
 *
 *  @return 右边x坐标
 */
- (double)getRight;
/**
 *  获取下边y坐标
 *
 *  @return 下边y坐标
 */
- (double)getBottom;
/**
 *  当前局域是否包含坐标
 *
 *  @param x x坐标
 *  @param y y坐标
 *
 *  @return
 */
- (BOOL)containPointx:(double)x y:(double)y;
/**
 *  是否包含矩形
 *
 *  @param target JCEnvelop对象
 *
 *  @return
 */
- (BOOL)containExtent:(JCEnvelop *)target;
/**
 *  是否与其他矩形相交
 *
 *  @param left   左x
 *  @param top    上y
 *  @param right  右x
 *  @param bottom 下y
 *
 *  @return
 */
- (BOOL)intersect:(double)left top:(double)top right:(double)right bottom:(double)bottom;
/**
 *  是否与其他矩形相交
 *
 *  @param target JCEnvelop对象
 *
 *  @return
 */
- (BOOL)intersectExtent:(JCEnvelop *)target;
/**
 *  与其他矩形的距离
 *
 *  @param target JCEnvelop对象
 *
 *  @return 距离
 */
- (double)distanceSq:(JCEnvelop *)target;

@end
