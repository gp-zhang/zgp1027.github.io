//
//  JCNavicStatus.h
//  JCMapKit
//
//  Created by JCNetwork on 16/3/5.
//  Copyright © 2016年 JCNetwork. All rights reserved.
//

#define SUGGESTION_FRONT            0
#define SUGGESTION_FRONT_LEFT       1
#define SUGGESTION_LEFT             2
#define SUGGESTION_BACKWARD_LEFT    3
#define SUGGESTION_BACKWARD         4
#define SUGGESTION_BACKWARD_RIGHT   5
#define SUGGESTION_RIGHT            6
#define SUGGESTION_FRONT_RIGHT      7

#define NEXT_SEG_DIRECTION_TURNLEFT     0
#define NEXT_SEG_DIRECTION_TURNRIGHT    1
#define NEXT_SEG_DIRECTION_ARRIVE   2

#import <Foundation/Foundation.h>
 /**
 *  返回当前位置相对于导航链的状态
 */
@interface JCNavicStatus : NSObject
/**
 *  投影坐标x
 */
@property (nonatomic,assign)double projectionx;
/**
 *  投影坐标y
 */
@property (nonatomic,assign)double projectiony;
/**
 *  拐点坐标x
 */
@property (nonatomic,assign)double targetx;
/**
 *  拐点坐标y
 */
@property (nonatomic,assign)double targety;
/**
 *  当前位置到投影坐标的距离
 */
@property (nonatomic,assign)double distprojection;
/**
 *  位置到目标端点的距离
 */
@property (nonatomic,assign)double disttarget;
/**
 *  段方向角
 */
@property (nonatomic,assign)double segazimuth;
/**
 *  位置到目标端点的方位角
 */
@property (nonatomic,assign)double targetazimuth;
/**
 *  段的索引
 */
@property (nonatomic,assign)int segindex;
/**
 *  对下一步移动的建议,作为索引取数组中的文本:@[@"前行",@"左前行",@"向左行",@"后转调头",@"后转调头",@"后转调头",@"向右行",@"右前行"]
 */
@property (nonatomic,assign)int suggestion;
/**
 *  到达目标端点后的建议,作为索引取数组中的文本:@[@"左转",@"右转",@"到达"]
 */
@property (nonatomic,assign)int nextsegdirection;
/**
 *  本结果是否有效
 */
@property (nonatomic,assign)int validate;
@end
