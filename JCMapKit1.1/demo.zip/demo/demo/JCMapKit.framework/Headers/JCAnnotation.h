//
//  JCAnnotation.h
//  JCMapKit
//
//  Created by JCNetwork on 15/12/17.
//  Copyright © 2015年 JCNetwork. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JCMapView;
@class JCAnnotationView;
/**
 *  Annotation
 */
@interface JCAnnotation : NSObject
/**
 *  位置坐标
 */
@property (nonatomic, assign) CGPoint point;
/**
 *  x=0时为左右居中、y请自行调整
 */
@property (nonatomic, assign) CGPoint offset;
/**
 *  标题
 */
@property (nonatomic, strong) NSString *title;
/**
 *  Annotation图标
 */
@property (nonatomic, strong) UIImage *image;

/**
 *  关联的外部数据
 */
@property (nonatomic, strong) id dataObject;
/**
 *  AnnotationView
 */
@property (nonatomic, readonly) JCAnnotationView *view;
/**
 *  关联的地图
 */
@property (nonatomic, readonly, weak)JCMapView *mapView;
/**
 *  是否根据Map大小动态调整Annotation的大小及位置、区域型Annotation需要设置此参数,默认NO
 */
@property (nonatomic,assign)BOOL shouldScaleWithSupper;
/**
 *  气泡开关,默认YES
 */
@property (nonatomic, assign) BOOL shouldShowCalloutView;

/**
 *  初始化
 *
 *  @param point    Annotation位置坐标
 *
 *  @return Annotation实例
 */
+ (id)annotationWithPoint:(CGPoint)point;
/**
 *  移除AnnotationView
 */
- (void)removeFromMapView;

@end


