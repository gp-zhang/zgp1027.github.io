//
//  JCUserAnnotationView.h
//  Demo
//
//  Created by zgp on 16/5/27.
//  Copyright © 2016年 zgp. All rights reserved.
//

#import <JCMapKit/JCMapKit.h>

@interface JCUserAnnotationView : JCAnnotationView
- (id)initWithAnnotation:(JCAnnotation *)annotation;

@end
