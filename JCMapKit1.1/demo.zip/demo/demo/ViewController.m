//
//  ViewController.m
//  demo
//
//  Created by zgp on 16/10/27.
//  Copyright © 2016年 重庆甲虫网络科技有限公司. All rights reserved.
//

#import "ViewController.h"
#import <JCMapKit/JCMapKit.h>
#import "JCUserAnnotationView.h"
@interface ViewController ()<JCMapKitDelegate,JCMapViewDelegate>
{
    JCMapLocation *startPoint;
    CGPoint endpoint;
    NSTimer *timer;
}
@property (nonatomic,strong)JCAnnotation *userAnnotation;
@property (nonatomic,strong)JCMapView *mapView;

@end

@implementation ViewController
@synthesize mapView;

- (void)run
{
    if(startPoint.mapX > 600.0 && startPoint.mapY < 250.0)
    {
        startPoint = [[JCMapLocation alloc] initWithFloor:startPoint.floorIndex X:startPoint.mapX-20.0 Y:startPoint.mapY];
    }
    else if((startPoint.mapX >= 600 && startPoint.mapX < 700) && startPoint.mapY < 1600)
    {
        startPoint = [[JCMapLocation alloc] initWithFloor:startPoint.floorIndex X:startPoint.mapX Y:startPoint.mapY+20.0];

    }
    else if(startPoint.mapY >= 1600 && startPoint.mapX <= 1800)
    {
        startPoint = [[JCMapLocation alloc] initWithFloor:startPoint.floorIndex X:startPoint.mapX+20.0 Y:startPoint.mapY];

    }
    else
    {
        startPoint = [[JCMapLocation alloc] initWithFloor:0 X:1520 Y:200];

    }
    
    JCMapLocation *loc = [[JCMapKit getInstance] getProjectionLocation:startPoint];
    self.userAnnotation.point = CGPointMake(loc.mapX, loc.mapY);
   
    [self.mapView setNavigateChain: [[JCMapKit getInstance] getNavigateChain:startPoint end:[[JCMapLocation alloc] initWithFloor:0 X:endpoint.x Y:endpoint.y]]];
    //            mapFrame.updateLocation(startPoint);
}



- (void)viewDidLoad {
    [super viewDidLoad];
    [[JCMapKit getInstance] loadBuilding:[[NSBundle mainBundle] pathForResource:@"map" ofType:@"plist"]];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.mapView = [[JCMapView alloc] initWithFrame:self.view.bounds];
    [mapView loadBuilding:[[JCMapKit getInstance]  getBuilding]];
    [mapView setCurrentFloor:0];
    mapView.delegate = self;
    [self.view addSubview:mapView];
//    mapView.rotateWhenNavigate = YES;

//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        mapView.rotateWhenNavigate = NO;
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            mapView.navigateChain = nil;
//
//        });
//        
//    });
    [mapView addLayer:LAYER_ELEVATOR image:[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"marker_wc" ofType:@"png"]]];
    [mapView addLayer:LAYER_STALL image:nil];
    
    NSArray *features = [mapView getLayerFeatures:@"stall"];
    
    for (JCFeature *feature in features) {
        if ([[feature getName] containsString:@"5"]) {
            [mapView setStallColor:feature color:[UIColor greenColor]];
        }
    }
    [[JCMapKit getInstance] setDelegate:self];
    [[JCMapKit getInstance] startUpdateUserLocation];
    
//    [[JCMapKit getInstance] stopUpdateUserLocation];
//    [[JCMapKit getInstance] setDelegate:nil];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)updateUserLocation:(JCMapLocation *)location
{
    NSLog(@"%@",location);
    if (self.userAnnotation == nil) {
        self.userAnnotation = [JCAnnotation annotationWithPoint:CGPointMake(location.mapX, location.mapY)];
        self.userAnnotation.shouldScaleWithSupper = NO;
        [self.mapView addAnnotation:self.userAnnotation animated:YES];
    }
    self.userAnnotation.point = CGPointMake(location.mapX, location.mapY);
    
    if (self.mapView.navigateChain) {
        [self route:endpoint];
    }
}

- (JCAnnotationView *)mapView:(JCMapView *)mapView viewForAnnotation:(JCAnnotation *)annotation{
    if (annotation == self.userAnnotation) {
        JCUserAnnotationView *View = [[JCUserAnnotationView alloc] initWithAnnotation:annotation];
        View.frame = CGRectMake(0, 0, 30, 30);
        return View;
    }
    
    return nil;
};


- (void)mapView:(JCMapView *)mapView tappedFeature:(JCFeature *)feature
{
    self.mapView.calloutView.titleLabel.text = [feature getName];
    [self.mapView showCalloutForPosition:[feature getCenter] offset:CGPointZero animated:YES];
}

- (void)mapView:(JCMapView *)mapView tappedOnLocation:(CGPoint)location
{
    NSLog(@"%@",NSStringFromCGPoint(location));
    endpoint = location;

    
    [self route:location];
}


- (void)route:(CGPoint )point{
    JCMapLocation *start = [[JCMapLocation alloc] initWithFloor:0 X:self.userAnnotation.point.x Y:self.userAnnotation.point.y];
    JCMapLocation *end = [[JCMapLocation alloc] initWithFloor:0 X:point.x Y:point.y];
    [self.mapView setNavigateChainColor:[UIColor redColor]];
    [self.mapView setNavigateRoundCornerColor:[UIColor greenColor]];

    JCNavigateChain *nc = [[JCMapKit getInstance] getNavigateChain:start end:end];
    [self.mapView setNavigateChain:nc];
    
    
    

}

- (void)updateHeading:(CLHeading *)newHeading
{
    JCNavicStatus *status = [self.mapView.navigateChain getStatus:[[JCMapLocation alloc] initWithFloor:0 X:self.userAnnotation.point.x Y:self.userAnnotation.point.y] azimuth:newHeading.magneticHeading];
    
    NSArray *suggestions = @[@"前行",@"左前行",@"向左行",@"后转调头",@"后转调头",@"后转调头",@"向右行",@"右前行"];
    NSArray *nextsegdirections = @[@"左转",@"右转",@"到达"];
    
    NSLog(@"%@ %.1f米后 %@",suggestions[status.suggestion],status.disttarget,nextsegdirections[status.nextsegdirection]);;
}

@end
