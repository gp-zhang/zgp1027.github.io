//
//  AppDelegate.h
//  demo
//
//  Created by zgp on 16/10/27.
//  Copyright © 2016年 重庆甲虫网络科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

