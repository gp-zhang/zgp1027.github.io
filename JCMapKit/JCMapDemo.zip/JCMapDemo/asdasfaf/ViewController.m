//
//  ViewController.m
//  asdasfaf
//
//  Created by JCNetwork-iMac on 16/1/28.
//  Copyright © 2016年 JCNetwork-iMac. All rights reserved.
//

#import "ViewController.h"
#import <JCMapKit/JCMapKit.h>
@interface ViewController ()<JCAnnotationDelegate,JCMapViewDelegate>
@property (nonatomic, strong)JCAnnotation *userAnnotation;
@property (nonatomic , strong) JCMapKit *mapKit;
@property (nonatomic , strong) JCMapView *mMapView;
@property (nonatomic,strong)JCMapLayer *baseLayer;
@property (nonatomic , strong )JCAnnotation *nodePointAnnotation;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSString *map1 = [[NSBundle mainBundle] pathForResource:@"map_hlw_new" ofType:@"jmk"];
    self.mapKit = [[JCMapKit alloc]initWithBuilding:@"华龙网"];
    [self.mapKit addFloorPath:map1 des:@"底楼" number:1];///num 楼层号
    //    [self.building1 addFloorPath:map2 des:@"二楼" number:2];
    //    [self.building1 addFloorPath:map3 des:@"三楼" number:3];
    //    [self.building1 addFloorPath:map4 des:@"四楼" number:4];
    //    [self.building1 addFloorPath:map5 des:@"五楼" number:1];
    [self setupMap:self.mapKit Index:0];///按添加顺序生成索引值，从0开始依次增加
}
- (void)setupMap:(JCMapKit *)mapkit Index:(int)index{
    self.mMapView = [[JCMapView alloc] initWithFrame:self.view.bounds];
    self.mMapView.mapViewDelegate = self;
    _mMapView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _mMapView.clipsToBounds = YES;
    self.baseLayer = (JCMapLayer *)[mapkit mapGetLayer:@"base" Index:index];
    [_mMapView displayMap:_baseLayer.image];
    
    float widthScale = self.view.frame.size.width/_baseLayer.image.size.width;
    float heightScale = self.view.frame.size.height/_baseLayer.image.size.height;
    _mMapView.minimumZoomScale = widthScale<heightScale?widthScale:heightScale;
    _mMapView.maximumZoomScale = widthScale>heightScale?widthScale:heightScale;;
    [_mMapView setZoomScale:widthScale<heightScale?widthScale:heightScale animated:NO];
    [self.view insertSubview:_mMapView atIndex:0];
    
    NSString *bundlePath=[[NSBundle mainBundle]pathForResource:@"JCMapKit" ofType:@"bundle"];
    UIImage *image = nil;
    if (bundlePath) {
        NSBundle *imageBundle=[NSBundle bundleWithPath:bundlePath];
        NSString *path=[imageBundle pathForResource:@"pin_green" ofType:@"png"];
        image = [UIImage imageWithContentsOfFile:path];
    }
    NSArray *stall = [mapkit mapGetLayer:@"stall" Index:index];
    
    for (int i = 0; i < stall.count; i++) {
        JCStallLayer *stall1 = (JCStallLayer *)stall[i];
        JCAnnotation *annotation = [JCAnnotation annotationWithPoint:stall1.point];
        annotation.delegate = self;
        //    annotation.offset = CGPointMake(0, 0);
        annotation.title = stall1.title;
        annotation.dataObject = stall1;
        annotation.shouldShowCalloutView = YES;
        [_mMapView addAnnotation:annotation animated:NO];
    }
    
    NSArray *wc = [mapkit mapGetLayer:@"wc" Index:index];
    for (int i = 0; i < wc.count; i++) {
        JCPointLayer *stall1 = (JCPointLayer *)wc[i];
        JCAnnotation *annotation = [JCAnnotation annotationWithPoint:stall1.point];
        annotation.image = image;
        
        //    annotation.offset = CGPointMake(0, 0);
        annotation.dataObject = stall1;
        [_mMapView addAnnotation:annotation animated:NO];
    }
    NSArray *wc2 = [mapkit mapGetLayer:@"stairway" Index:index];
    for (int i = 0; i < wc2.count; i++) {
        JCPointLayer *stall1 = (JCPointLayer *)wc2[i];
        JCAnnotation *annotation = [JCAnnotation annotationWithPoint:stall1.point];
        //    annotation.offset = CGPointMake(0, 0);
        annotation.dataObject = stall1;
        [_mMapView addAnnotation:annotation animated:NO];
    }
    //
    NSArray *wc3 = [mapkit mapGetLayer:@"port" Index:index];
    for (int i = 0; i < wc3.count; i++) {
        JCPointLayer *stall1 = (JCPointLayer *)wc3[i];
        JCAnnotation *annotation = [JCAnnotation annotationWithPoint:stall1.point];
        annotation.dataObject = stall1;
        [_mMapView addAnnotation:annotation animated:NO];
    }
    /**
     *  地图加载完成后再执行此方法
     */
    [mapkit setUpLocationManager];
    [mapkit startUpdateUserLocation];
    
    
    [mapkit setUPNaviManager];
    [mapkit getUserpointMessage:self.userAnnotation.point];//每次更新位置要重新传入定位点的坐标。
    [mapkit navigationPlanning:^(double projectionx, double projectiony, double targetx, double targety, double distprojection, double disttarget, double segazimuth, double targetazimuth, int segindex, int suggestion, int nextsegdirection, int validate, double heading) {
        //        NSLog(@"projectionx:%lf,projectiony:%lf,targetx:%lf,targety:%lf,distprojection:%lf,disttarget:%lf,segazimuth:%lf,targetazimuth:%lf,segindex:%d,suggestion:%d,nextsegdirection:%d,validate:%d",projectionx,projectiony,targetx,targety,distprojection,disttarget,segazimuth,targetazimuth,segindex,suggestion,nextsegdirection,validate);
        NSArray *nextSegdirection = @[@"右转",@"左转",@"到达"];
        NSArray *sugList = @[@"前行",@"左前行",@"向左行",@"后转调头",@"后转调头",@"后转调头",@"向右转",@"右前行"];
        NSLog(@"%@",[NSString stringWithFormat:@"%@ %.1f米后%@",sugList[suggestion],disttarget,nextSegdirection[nextsegdirection]]);
        UIBezierPath *path1 = [UIBezierPath bezierPath];
        [path1 moveToPoint:self.userAnnotation.point];
        [path1 addLineToPoint:CGPointMake(projectionx, projectiony)];
        
        UIBezierPath *path2 = [UIBezierPath bezierPath];
        [path2 moveToPoint:self.userAnnotation.point];
        [path2 addLineToPoint:CGPointMake(targetx, targety)];
        
        [self.mMapView setendPath:path2 Options:@{@"color":[UIColor blackColor],@"lineWidth":[NSNumber numberWithFloat:10.0]}];
    }];
    NSArray *nodes = [mapkit getRoute:CGPointMake(400, 1200) endPoint:CGPointMake(1674, 1765) startIndex:0 endIndex:0];
    for (int i = 0; i < nodes.count; i++) {
        self.nodePointAnnotation = [JCAnnotation annotationWithPoint:CGPointFromString(nodes[i])];
        self.nodePointAnnotation.delegate = self;
        [_mMapView addAnnotation:self.nodePointAnnotation animated:NO];
    }
    if (nodes) {
        UIBezierPath *path = [mapkit getPathWithNodes:nodes Index:0];
        if (path) {
            [self.mMapView setPath:path Options:@{@"color":[UIColor redColor],@"lineWidth":[NSNumber numberWithFloat:20.0]}];
        }
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateUserLocation:) name:JCUpdateUserLocation object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateUserLocation:) name:JCUpdateUserLocation object:nil];
    
}
- (JCAnnotationView *)mapView:(JCMapView *)mapView viewForAnnotation:(JCAnnotation *)annotation{
    if (annotation == self.userAnnotation) {
        JCAnnotationView *View = [[JCAnnotationView alloc] initWithAnnotation:annotation];
        View.frame = CGRectMake(0, 0, 50, 50);
        View.layer.masksToBounds = YES;
        View.layer.cornerRadius  = 25;
        View.backgroundColor = [UIColor redColor];
        return View;
    }
    else if ([annotation.dataObject isKindOfClass:[JCStallLayer class]]) {
        JCAnnotationView *View = [[JCAnnotationView alloc] initWithAnnotation:annotation];
        JCStallLayer *stall = (JCStallLayer *)annotation.dataObject;
        View.layer.masksToBounds = YES;
        View.layer.borderWidth = 1;
        View.layer.borderColor = [UIColor lightGrayColor].CGColor;
        annotation.shouldScaleWithSupper = YES;
        View.backgroundColor = stall.color;
        View.bounds = CGRectMake(0, 0, stall.size.width, stall.size.height);
        UILabel *label = [[UILabel alloc] initWithFrame:View.bounds];
        label.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
        label.textColor = [UIColor whiteColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.text = stall.title;
        label.numberOfLines = 2;
        label.adjustsFontSizeToFitWidth = YES;
        [View addSubview:label];
        return View;
    }else if (annotation == self.nodePointAnnotation){
        JCAnnotationView *View = [[JCAnnotationView alloc] initWithAnnotation:annotation];
        View.frame = CGRectMake(0, 0, 10, 10);
        View.layer.masksToBounds = YES;
        View.layer.cornerRadius  = 5;
        View.backgroundColor = [UIColor greenColor];
        return View;
    }
    
    return nil;
}

- (void)mapView:(JCMapView *)mapView tappedOnAnnotation:(JCAnnotation *)annotation
{
    //    if (annotation.class) {
    //        <#statements#>
    //    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)updateUserLocation:(NSNotification *)sender
{
    CGPoint point = [[sender.userInfo objectForKey:@"location"] CGPointValue];
    if (isnan(point.x) || isnan(point.y) || isinf(point.x) || isinf(point.y)) {
        return;
    }
    point = CGPointMake(point.x/self.baseLayer.scalex, point.y/self.baseLayer.scaley);
    if (self.userAnnotation == nil) {
        self.userAnnotation = [JCAnnotation annotationWithPoint:point];
        self.userAnnotation.delegate = self;
        [self.mMapView addAnnotation:self.userAnnotation animated:YES];
    }
    self.userAnnotation.point = point;
    [self.userAnnotation updatePosition];
    //    printf("%f %f",point.x,point.y);
    //    NSLog(@"%@",sender.userInfo);
}

@end
