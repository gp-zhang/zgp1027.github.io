//
//  JCAnnotationView.h
//  JCMapKit
//
//  Created by zgp on 15/12/18.
//  Copyright © 2015年 zgp. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JCAnnotation;
/**
 *  大头针视图
 */
@interface JCAnnotationView : UIView
/**
 *  大头针
 */
@property (nonatomic,assign)JCAnnotation *annotation;
/**
 *  初始化方法
 *
 *  @param annotation 大头针
 *
 *  @return 大头针视图实例
 */
- (id)initWithAnnotation:(JCAnnotation *)annotation;
@end
