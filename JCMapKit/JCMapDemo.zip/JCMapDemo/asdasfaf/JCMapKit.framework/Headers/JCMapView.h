//
//  JCMapView.h
//  JCMapKit
//
//  Created by zgp on 15/Users/jcnetwork-imac/Library/Developer/Xcode/DerivedData/JCShowMap-cydlugqtkacfdqgplnmhmxykvsoh/Build/Products/Debug-iphoneos/JCShowMap.framework/12/17.
//  Copyright © 2015年 zgp. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JCAnnotation;
@class JCAnnotationCallOutView;
@protocol JCMapViewDelegate;
/**
 *  地图视图
 */
@interface JCMapView : UIScrollView
/**
 *  地图加载,zoomScale/minimumZoomScale/maximumZoomScale在此方法后调用
 *
 *  @param image 图片,请控制图片尺寸,防止内存占用过大
 */
- (void)displayMap:(UIImage *)image;
/**
 *  添加大头针
 *
 *  @param annotation 大头针
 *  @param animate    YES会出现掉落动画
 */
- (void)addAnnotation:(JCAnnotation *)annotation animated:(BOOL)animate;
/**
 *  批量添加大头针
 *
 *  @param annotations 大头针数组
 *  @param animate YES会出现掉落动画
 */
- (void)addAnnotations:(NSArray *)annotations animated:(BOOL)animate;
/**
 *  移除大头针
 *
 *  @param annotation 大头针
 */
- (void)removeAnnotation:(JCAnnotation *)annotation;
/**
 *  设置路径
 *
 *  @param path   路径
 *  @param option 路径相关参数、示例:@{@"color":[UIColor redColor],@"lineWidth":[NSNumber numberWithFloat:20.0]}
 */
- (void)setPath:(UIBezierPath *)path Options:(NSDictionary *)option;
/**
 *  基于当前缩放比例的点的转换
 *
 *  @param point 原始点
 *
 *  @return 缩放计算后的点
 */
- (CGPoint)zoomRelativePoint:(CGPoint)point;
/**
 *  大头针被选中后，会居中显示
 *
 *  @param annotation 大头针
 *  @param animate    动画开关
 */
- (void)selectAnnotation:(JCAnnotation *)annotation animated:(BOOL)animate;
/**
 *  居中显示点
 *
 *  @param point   需要居中的点
 *  @param animate 动画开关
 */
- (void)centerOnPoint:(CGPoint)point animated:(BOOL)animate;
/**
 *  显示气泡
 *
 *  @param annotation 气泡关联的大头针
 *  @param animated   动画开关
 */
- (void)showCalloutForAnnotation:(JCAnnotation *)annotation animated:(BOOL)animated;
/**
 *  隐藏气泡
 */
- (void)hideCallOut;
/**
 *  气泡视图,只支持单一气泡
 */
@property (nonatomic, strong) JCAnnotationCallOutView *calloutView;
/**
 *  地图代理,不同于scrollView delegate,请勿设置self.delegate
 */
@property ( nonatomic, assign) id<JCMapViewDelegate> mapViewDelegate;
/**
 *  地图初始大小
 */
@property (readwrite, nonatomic, assign) CGSize originalSize;

@end

@protocol JCMapViewDelegate <NSObject>

@optional
/**
 *  大头针点击事件
 *
 *  @param mapView 关联地图
 *  @param annotation 被点击的大头针
 */
- (void)mapView:(JCMapView *)mapView tappedOnAnnotation:(JCAnnotation *)annotation;

/**
 *  缩放比例变化后
 *
 *  @param mapView 关联地图
 *  @param level   新的缩放比例
 */
- (void)mapView:(JCMapView *)mapView hasChangedZoomLevel:(CGFloat)level;

@end
