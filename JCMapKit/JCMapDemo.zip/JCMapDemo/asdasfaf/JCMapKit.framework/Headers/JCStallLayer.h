//
//  StallLayer.h
//  JCMapKit
//
//  Created by JCNetwork-iMac on 16/1/28.
//  Copyright © 2016年 JCNetwork-iMac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
/**
 *  区域类图层
 */
@interface JCStallLayer : NSObject
/**
 *  绘图的路径
 */
@property(nonatomic ,strong)UIBezierPath *path;
/**
 *  stall图层的point
 */
@property(nonatomic ,assign)CGPoint point;
/**
 *  stall图层的标题
 */
@property(nonatomic ,strong)NSString *title;
/**
 *  stall图层的颜色
 */
@property(nonatomic ,strong)UIColor *color;
/**
 *  stall图层的大小
 */
@property(nonatomic ,assign)CGSize size;
/**
 *  备用
 */
@property(nonatomic ,assign)int type;
/**
 *  stall的描述，暂时没有。
 */
@property(nonatomic ,assign)NSString *des;
@end
