//
//  JCAnnotation.h
//  JCMapKit
//
//  Created by zgp on 15/12/17.
//  Copyright © 2015年 zgp. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JCMapView;
@class JCAnnotationView;
@protocol JCAnnotationDelegate;
/**
 *  大头针
 */
@interface JCAnnotation : NSObject
/**
 *  位置坐标
 */
@property (nonatomic, assign) CGPoint point;
/**
 *  x=0时为左右居中、y请自行调整
 */
@property (nonatomic, assign) CGPoint offset;
/**
 *  标题
 */
@property (nonatomic, strong) NSString *title;
/**
 *  大头针图标
 */
@property (nonatomic, strong) UIImage *image;

/**
 *  关联的外部数据
 */
@property (nonatomic, strong) id dataObject;
/**
 *  大头针视图
 */
@property (nonatomic, readonly) JCAnnotationView *view;
/**
 *  关联的地图
 */
@property (nonatomic, readonly, weak)JCMapView *mapView;
/**
 *  是否根据Map大小动态调整大头针的大小及位置、区域型大头针需要设置此参数,默认NO
 */
@property (nonatomic,assign)BOOL shouldScaleWithSupper;
/**
 *  气泡开关,默认YES
 */
@property (nonatomic, assign) BOOL shouldShowCalloutView;
/**
 *  设置代理，用于自定义大头针样式
 */
@property (nonatomic, assign) id<JCAnnotationDelegate> delegate;
/**
 *  初始化
 *
 *  @param point    大头针位置坐标
 *  @param delegate 代理,不能为空
 *
 *  @return 大头针实例
 */
+ (id)annotationWithPoint:(CGPoint)point;
/**
 *  移除大头针视图
 */
- (void)removeFromMapView;
/**
 *  更新位置
 */
- (void)updatePosition;
@end

@protocol JCAnnotationDelegate
@required
/**
 *  协议方法,用于大头针视图的创建
 *
 *  @param mapView    关联的地图
 *  @param annotation 大头针
 *
 *  @return 大头针视图
 */
- (JCAnnotationView *)mapView:(JCMapView *)mapView viewForAnnotation:(JCAnnotation *)annotation;

@end
