//
//  JCPointLayer.h
//  JCMapKit
//
//  Created by JCNetwork-iMac on 16/1/28.
//  Copyright © 2016年 JCNetwork-iMac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
/**
 *  点类型图层
 */
@interface JCPointLayer : NSObject
/**
 *  wc图层和stair图层的位置
 */
@property (nonatomic ,assign) CGPoint point;
/**
 *
 */
@property (nonatomic ,assign) int type;
/**
 *  title
 */
@property (nonatomic ,assign) NSString *title;
@end
