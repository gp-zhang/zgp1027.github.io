//
//  JCMapLayer.h
//  JCMapKit
//
//  Created by JCNetwork-iMac on 16/1/28.
//  Copyright © 2016年 JCNetwork-iMac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
/**
 *  底图类,包含地图图片及相关参数
 */
@interface JCMapLayer : NSObject
/**
 *  地图图层图片
 */
@property(nonatomic, strong) UIImage *image;
/**
 *  x轴比例
 */
@property(nonatomic, assign) float scalex;
/**
 *  y轴比例
 */
@property(nonatomic, assign) float scaley;
/**
 *  地图方向与正北的夹角
 */
@property(nonatomic, assign) float azimuth;

@end
