//
//  JCMapKit.h
//  JCMapKit
//
//  Created by zgp on 16/1/31.
//  Copyright © 2016年 JCNetwork-iMac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JCMapView.h"
#import "JCAnnotation.h"
#import "JCAnnotationView.h"
#import "JCAnnotationCallOutView.h"
#import "JCMapLayer.h"
#import "JCPointLayer.h"
#import "JCStallLayer.h"
#define JCUpdateUserLocation @"JCUpdateUserLocation"

@interface JCMapKit : NSObject

/**
 *  支持的layer类型
 */
@property (nonatomic,strong)NSMutableArray *supportLayers;

/**
 *  初始化建筑
 *
 *  @param building 名称
 *
 *  @return 类实例
 */
- (instancetype)initWithBuilding:(NSString *)building;
/**
 *  添加地图
 *
 *  @param path   JMK文件路径
 *  @param des    描述
 *  @param number 楼层编号
 */
- (void)addFloorPath:(NSString *)path
                 des:(NSString *)des
              number:(int)number;

/**
 *  通过layername获取对应的数据
 *
 *  @param name   图层类型名称
 *  @param Index 地图索引,按添加顺序依次增长,从0开始
 *
 *  @return layer数组(stall对应StallLayer,其他对应PointLayer)
 */
- (id)mapGetLayer:(NSString *)name
           Index:(int)index;
/**
 *  初始化定位,地图加载完成后再调用此方法
 */
- (void)setUpLocationManager;
/**
 *  开始定位//定位返回为实际坐标，以米为单位，在地图中使用需要转换为像素单位
 */
- (void)startUpdateUserLocation;
/**
 *  停止定位
 */
- (void)stopUpdateUserLocation;
/**
 *  初始化导航模块,使用导航功能前/所有地图加载完成后-》使用
 */
- (void)setUPNaviManager;
/**
 *  获取路径节点(以像素为单位，mapView是像素为单位)
 *
 *  @param spoint 起始点坐标(像素)
 *  @param ePoint 终点坐标(像素)
 *  @param sindex 起始点地图索引 按添加顺序依次增长,从0开始
 *  @param eindex 终点地图索引 按添加顺序依次增长,从0开始
 *
 *  @return 节点数组
 */
- (NSArray *)getRoute:(CGPoint)spoint endPoint:(CGPoint)ePoint startIndex :(int)sindex endIndex:(int)eindex;
/**
 *  通过节点数组生成Path
 *
 *  @param nodes 节点数组
 *  @param index 当前地图索引 按添加顺序依次增长,从0开始
 *
 *  @return 返回UIBezierPath, JCMapView->setPath:(UIBezierPath *)path Options:(NSDictionary *)option;
 */
- (UIBezierPath *)getPathWithNodes:(NSArray *)nodes Index:(int)index;


@end
