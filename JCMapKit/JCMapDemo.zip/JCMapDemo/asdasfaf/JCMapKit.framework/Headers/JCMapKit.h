//
//  JCMapKit.h
//  JCMapKit
//
//  Created by zgp on 16/1/31.
//  Copyright © 2016年 JCNetwork-iMac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JCMapView.h"
#import "JCAnnotation.h"
#import "JCAnnotationView.h"
#import "JCAnnotationCallOutView.h"
#import "JCMapLayer.h"
#import "JCPointLayer.h"
#import "JCStallLayer.h"
#define JCUpdateUserLocation @"JCUpdateUserLocation"
#define SUGGESTION_FRONT            0
#define SUGGESTION_FRONT_LEFT       1
#define SUGGESTION_LEFT             2
#define SUGGESTION_BACKWARD_LEFT    3
#define SUGGESTION_BACKWARD         4
#define SUGGESTION_BACKWARD_RIGHT   5
#define SUGGESTION_RIGHT            6
#define SUGGESTION_FRONT_RIGHT      7

#define NEXT_SEG_DIRECTION_LEFT     0
#define NEXT_SEG_DIRECTION_RIGHT    1
#define NEXT_SEG_DIRECTION_ARRIVE   2
/**
 * 返回当前位置相对于导航链的状态
 * 设targetseg为当前位置到导航链上各个导航段的最近投影所在的导航段
 *
 *
 * projectionx, projectiony targetseg上的投影坐标
 * targetx, targety         targetseg上的端点(end)坐标
 * distprojection           位置到投影点的距离, 用于辅助判断偏航
 * disttarget               位置到目标端点的距离
 * segazimuth               导航链段方向角
 * targetazimuth            位置到目标端点的矢量的方位角
 * segindex                 targetseg的索引
 * seggestion               对下一步移动的建议
 * nextsegdirection         到达目标端点后的建议
 * validate                 本结果是否有效
 * heading                  地图旋转角度
 */
typedef void(^navigationPlanning)(double  projectionx,
                                  double  projectiony,
                                  double  targetx,
                                  double  targety,
                                  double  distprojection,
                                  double  disttarget,
                                  double  segazimuth,
                                  double  targetazimuth,
                                  int     segindex,
                                  int     suggestion,
                                  int     nextsegdirection,
                                  int     validate,
                                  double  heading);
@interface JCMapKit : NSObject
/**
 *  语音导航数据
 *
 *  @param navigationPlanning block包含的数据
 */
- (void)navigationPlanning:(navigationPlanning)navigationPlanning;
/**
 *  支持的layer类型
 */
@property (nonatomic,strong)NSMutableArray *supportLayers;

/**
 *  初始化建筑
 *
 *  @param building 名称
 *
 *  @return 类实例
 */
- (instancetype)initWithBuilding:(NSString *)building;
/**
 *  添加地图
 *
 *  @param path   JMK文件路径
 *  @param des    描述
 *  @param number 楼层编号
 */
- (void)addFloorPath:(NSString *)path
                 des:(NSString *)des
              number:(int)number;

/**
 *  通过layername获取对应的数据
 *
 *  @param name   图层类型名称
 *  @param Index 地图索引,按添加顺序依次增长,从0开始
 *
 *  @return layer数组(stall对应StallLayer,其他对应PointLayer)
 */
- (id)mapGetLayer:(NSString *)name
           Index:(int)index;
/**
 *  初始化定位,地图加载完成后再调用此方法
 */
- (void)setUpLocationManager;
/**
 *  开始定位//定位返回为实际坐标，以米为单位，在地图中使用需要转换为像素单位
 */
- (void)startUpdateUserLocation;
/**
 *  停止定位
 */
- (void)stopUpdateUserLocation;
/**
 *  初始化导航模块,使用导航功能前/所有地图加载完成后-》使用
 */
- (void)setUPNaviManager;
/**
 *  语音导航传入定位点的坐标
 *
 *  @param point 定位点的坐标
 */
- (void)getUserpointMessage:(CGPoint)point;
/**
 *  获取路径节点(以像素为单位，mapView是像素为单位)
 *
 *  @param spoint 起始点坐标(像素)
 *  @param ePoint 终点坐标(像素)
 *  @param sindex 起始点地图索引 按添加顺序依次增长,从0开始
 *  @param eindex 终点地图索引 按添加顺序依次增长,从0开始
 *
 *  @return 节点数组
 */
- (NSArray *)getRoute:(CGPoint)spoint endPoint:(CGPoint)ePoint startIndex :(int)sindex endIndex:(int)eindex;
/**
 *  通过节点数组生成Path
 *
 *  @param nodes 节点数组
 *  @param index 当前地图索引 按添加顺序依次增长,从0开始
 *
 *  @return 返回UIBezierPath, JCMapView->setPath:(UIBezierPath *)path Options:(NSDictionary *)option;
 */
- (UIBezierPath *)getPathWithNodes:(NSArray *)nodes Index:(int)index;


@end
