//
//  JCMapKit.h
//  JCMapKit
//
//  Created by zgp on 16/1/31.
//  Copyright © 2016年 JCNetwork-iMac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JCMapView.h"
#import "JCAnnotation.h"
#import "JCAnnotationView.h"
#import "JCAnnotationCallOutView.h"
#import "JCMapLayer.h"
#import "JCPointLayer.h"
#import "JCStallLayer.h"
#define JCUpdateUserLocation @"JCUpdateUserLocation"

@interface JCMapKit : NSObject

/**
 *  支持的layer类型
 */
@property (nonatomic,strong)NSMutableArray *supportLayers;

/**
 *  初始化建筑
 *
 *  @param building 名称
 *
 *  @return 类实例
 */
- (instancetype)initWithBuilding:(NSString *)building;
/**
 *  添加地图
 *
 *  @param path   JMK文件路径
 *  @param des    描述
 *  @param number 楼层编号
 */
- (void)addFloorPath:(NSString *)path
                 des:(NSString *)des
              number:(int)number;

/**
 *  通过layername获取对应的数据
 *
 *  @param name   图层类型名称
 *  @param Index 地图索引,按添加顺序依次增长,从0开始
 *
 *  @return layer数组(stall对应StallLayer,其他对应PointLayer)
 */
- (id)mapGetLayer:(NSString *)name
           Index:(int)index;
/**
 *  初始化定位,地图加载完成后再调用此方法
 */
- (void)setUpLocationManager;
/**
 *  开始定位
 */
- (void)startUpdateUserLocation;
/**
 *  停止定位
 */
- (void)stopUpdateUserLocation;
@end
